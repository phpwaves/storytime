from django.contrib import admin
from story.models import ZomatoItem, Line

admin.site.register(ZomatoItem)
admin.site.register(Line)

